package testRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;




@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"features"},
		glue = {"steps"},
		plugin = {"pretty", "json:target/json-report/cucumber.json"},
		dryRun = false,
		monochrome=true,
		tags = "@tag14"	
		//strict = true
		//name = {"Logo"}
		
		
		)
public class TestRunner {
	
	
	
	
	
	
	
	
	

}
