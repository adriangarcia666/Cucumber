package steps;

import static org.junit.Assert.fail;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import actions.Common_Actions;
import actions.EbayHomePage_Actions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Ebay_Home_Steps {

	WebDriver driver;
	Common_Actions common_actions;
	EbayHomePage_Actions ebayhomePage_actions;
	
	
	
	
	public Ebay_Home_Steps(Common_Actions common_actions,EbayHomePage_Actions ebayhomePage_actions) {
		this.common_actions = common_actions;
		this.ebayhomePage_actions = ebayhomePage_actions;
	}
	
	
	
	@Given("I am on Ebay Home Page")
	public void i_am_on_ebay_home_page() throws Exception {
	    
	    //driver.get("https://www.ebay.com/");
		common_actions.goToUrl("https://www.ebay.com/");
	    Thread.sleep(1000);
	}

	@When("I click on Advance Link")
	public void i_click_on_advance_link() {
		ebayhomePage_actions.clickAdvancedLink();
		
		
	}

	@Then("I navigate to Advance Seach Page")
	public void i_navigate_to_advance_seach_page() {
	   String expUrl ="https://www.ebay.com/sch/ebayadvsearch";
	   String actUrl = common_actions.getCurrentPageUrl();
	   if (!expUrl.equals(actUrl)) {
		   fail("Page does not navigate to expected page");
	   }
	   
	   
	}
	
	
	@When("I search for {string}")
	public void i_search_for_i_phone11(String str1) throws Exception {
		ebayhomePage_actions.searchAnItem(str1);
		ebayhomePage_actions.clickSearchButton();
		Thread.sleep(1000);
	    
	}

	
	@When("I search for {string} in {string} category")
	public void i_search_for_in_category(String string, String string2) throws Exception {
	    
		ebayhomePage_actions.searchAnItem(string);
		ebayhomePage_actions.selectCategoryOptions(string2);
		ebayhomePage_actions.clickSearchButton();	
		Thread.sleep(1000);
	}
	
	
	
	
	
	
	
	@Then("I validate atleast {int} search item present")
	public void i_validate_atleast_search_item_present(int count) throws Exception{
	    	int itemCountInt = ebayhomePage_actions.getSearchItemsCount();
	    	if(itemCountInt <= count) {
	    		
	    		fail("Less than"+ count +"result shown");
	    		
	    	}   	
		
	}

	
	
	
	@When("I click on {string}")
	public void i_click_on(String string) throws Exception {
		
		ebayhomePage_actions.clickOnLinkByText(string);
	    Thread.sleep(3000);
	    
	}

	@Then("I validate that page navigates to {string} and title contains {string}")
	public void i_validate_that_page_navigates_to_and_title_contains(String url, String title) {
	    String actUrl = common_actions.getCurrentPageUrl();
	    String actTitle = common_actions.getCurrentPageTitle();
	    
	    if(!actUrl.equals(url)) {
	    	
	    	fail("Page does navigate to expected url: "+ url);
	    }
	    
  if(!actTitle.contains(title)) {
	    	
	    	fail("Title is mismatch");
	    }
	    
		
		
	}
	
	
	
	
	
}
