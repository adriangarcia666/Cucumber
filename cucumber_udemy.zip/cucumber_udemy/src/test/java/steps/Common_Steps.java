package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Common_Steps {

	private WebDriver driver;
	
	
	
	
	
	@Before(order=1)
	public void setUp(){
		
		System.setProperty("webdriver.chrome.driver", "webDriver/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
		System.out.println("Global hook Before");
		
	}
	
	@After(order=1)
	
	public void testDown() throws Exception {
		
		driver.quit();
		Thread.sleep(1000);
		System.out.println("Global hook After");
		
	}
	
	
	
	
	
	
	
	
	public WebDriver getDriver() {
		
		return driver;
	}
	
	
	
}
