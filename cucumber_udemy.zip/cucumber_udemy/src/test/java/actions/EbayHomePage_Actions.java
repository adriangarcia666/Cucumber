package actions;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import elements.EbayHomePage_Elements;
import steps.Common_Steps;

public class EbayHomePage_Actions {
	
	private WebDriver driver;
	EbayHomePage_Elements ebayhomepage_elements;
	
	public EbayHomePage_Actions(Common_Steps common_steps) {
		
		this.driver = common_steps.getDriver();
		ebayhomepage_elements = new EbayHomePage_Elements(driver);		
	}
	
	public void clickAdvancedLink() {
		
		ebayhomepage_elements.advancedLink.click();
		
	}
	
	public void searchAnItem(String srchString) {
		
		
		ebayhomepage_elements.searchBox.sendKeys(srchString);
		
	}
	
	
	public void  clickSearchButton() {
		
		ebayhomepage_elements.srchButton.click();
	}
	
	
	public int getSearchItemsCount() {
		
		
		String ItemCount = ebayhomepage_elements.numOfItems.getText().trim();
		
		String ItemCount2 = ItemCount.replace(",", "");
    	int itemCountInt = Integer.parseInt(ItemCount2);
    	 	
		return itemCountInt;
	}
	
	
	public void selectCategoryOptions(String options) {
		
		List<WebElement> cat = ebayhomepage_elements.catOption;
		for(WebElement x : cat) {
			if(x.getText().trim().toLowerCase().equals(options.toLowerCase())) {
				
				x.click();
				break;
			}
			
		
	}
	}
	
	public void clickOnLinkByText(String Text) {
		
	driver.findElement(By.linkText(Text)).click();		
		
	}
		
		
		
		
		
		
		
	
	
	
	
	
	
	

}
