package elements;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EbayHomePage_Elements {

	WebDriver driver;
	
	
	@FindBy(xpath = "//*[@id=\"gh-as-a\"]") public WebElement advancedLink;
	@FindBy(xpath = "//*[@id=\"gh-ac\"]") public WebElement searchBox;
	@FindBy(xpath = "//*[@id=\"gh-btn\"]") public WebElement srchButton;
	@FindBy(xpath = "//select[@id='gh-cat']") public WebElement list;
	@FindBy(css = "#mainContent > div.s-answer-region.s-answer-region-center-top > div > div.clearfix.srp-controls__row-2 > div:nth-child(1) > div.srp-controls__control.srp-controls__count > h1 > span:nth-child(1)") public WebElement numOfItems;
	@FindBy(xpath = "//select[@id='gh-cat']/option") public List<WebElement> catOption;
	
	
	
	public EbayHomePage_Elements(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	
	
	
}
